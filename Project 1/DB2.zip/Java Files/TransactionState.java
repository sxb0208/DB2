


//Enum data structure to store possible types of states that a transaction can be in.
public enum TransactionState {

    ACTIVE,BLOCKED ,ABORTED ,COMMITTED;

}
