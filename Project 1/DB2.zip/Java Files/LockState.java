


//Enum data structure to store possible types of locks that can be imposed on a data item
public enum LockState {

    RL, WL, UL        //ReadLocked, WriteLocked and UnLocked
}
