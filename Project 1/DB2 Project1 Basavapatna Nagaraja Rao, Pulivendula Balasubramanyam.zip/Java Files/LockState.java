


//Enum data structure for storing possible types of locks that can be imposed on a data item
public enum LockState {

    RL, WL, UL
}
