


//Enum data structure for storing possible types of states that a transaction can be in.
public enum TransactionState {

    ACTIVE,BLOCKED ,ABORTED ,COMMITTED;

}
