*******************************Database Models and Implementation*******************************
		Steps to run the Transaction application
1. Download all the java files(5 files in the folder "Java Files") in to your computer.
2. Compile LockState.java, TransactionState.java, Lock.java, Transaction.java first.
3. Then Compile the Main.java file using javac Main.java
4. Then run the Main.java file by using the following syntax :
	java  Main InputFile.txt
			 where InputFile are Input_1, Input_2...., Input_7.
5. Then, an output file will be generated in the format : InputFile_output.txt
6. Open that output file to see the transaction opeartions performed for that input file.

All the Java code files are submitted in one folder.
All the Input files are formatted and are arranged in the folder "Input Files"
All the output files recorded are submitted in the folder "Output Files"

PseudoCode for the application is also submitted as "DB2 Project1 Completed Project Report"
All the above said files are zipped in one folder named "DB2 Project1 Basavapatna Nagaraja Rao, Pulivendula Balasubramanyam.zip"